import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "signup", urlPatterns = {"/signup"})
public class SignUpServlet extends HttpServlet {
    
    public static boolean validateCredentials(String fname, String lname, String mail, String password){
        boolean result = false;
        
        if(fname.isEmpty() || lname.isEmpty() || mail.isEmpty() || password.isEmpty()){
            return result;
        }
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb?autoReconnect=true&useSSL=false","jdbcuser","");
            
            String query = "INSERT INTO gadget_user(firstname, lastname, email, password) VALUES('" + fname + "','" + lname + "','" + mail + "','" + password + "')";
            Statement sta = conn.createStatement();
            
            int x1 = sta.executeUpdate(query);
            result = x1 != 0;
        }
        catch (SQLException | ClassNotFoundException ex) {
            System.out.println("ERROR = " + ex.getMessage());
        }
        
        return result;
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        RequestDispatcher view = request.getRequestDispatcher("/signup.jsp");
        view.forward(request, response); 
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String firstName = request.getParameter("firstname");
        String lastName = request.getParameter("lastname");
        String emailId = request.getParameter("email");
        String userPassword = request.getParameter("password");
        
        if(validateCredentials(firstName, lastName, emailId, userPassword)){
            HttpSession session = request.getSession();  
            session.setAttribute("email", emailId);
            session.setAttribute("type", "signup");
            
            response.sendRedirect("/HouseOfGadgets");
        }
        else{
            response.sendRedirect("/HouseOfGadgets/login");
        }
         
    }

    @Override
    public String getServletInfo() {
        return "User signup servlet!";
    }

}