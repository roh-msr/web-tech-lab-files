package productsPackage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "purchase", urlPatterns = {"/purchase"})
public class PurchaseServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        HttpSession session = request.getSession();  
        if(session.getAttribute("email") == null){
            response.sendRedirect("/HouseOfGadgets/login");
        }
        else{
            session.setAttribute("buy", "1");
            
            int key, value;
            HashMap<Integer, Integer> hm = productsPackage.ProductsListServlet.items;
            HashSet<Integer> my_products = new HashSet();
            int user_id = -1;
            
            try{
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb?autoReconnect=true&useSSL=false","jdbcuser","");
                
                PreparedStatement user_ps = conn.prepareStatement("SELECT id FROM gadget_user WHERE email=?");  
                user_ps.setString(1, (String)session.getAttribute("email"));  
                
                ResultSet rs = user_ps.executeQuery();
                rs.next();
                
                user_id = rs.getInt("id");
                
                PreparedStatement ps = conn.prepareStatement("UPDATE hog_products SET stock=stock-? WHERE id=?");

                for (Map.Entry mapElement : hm.entrySet()) {
                    key = (Integer) mapElement.getKey();
                    value = (Integer) mapElement.getValue();

                    ps.setInt(1, value);
                    ps.setInt(2, key);
                    ps.executeUpdate();
                    
                    my_products.add(key);
                }
            }
            catch (SQLException | ClassNotFoundException ex) {
                System.out.println("ERROR = " + ex.getMessage());
            }
            
            Cookie[] cookies;
            cookies = request.getCookies();
            Cookie ck;
            String previousList = "";
            
            if(cookies != null) {
                for (Cookie cookie : cookies) {
                    if(cookie.getName().equals(String.valueOf(user_id))){
                        previousList = cookie.getValue();
                        
                    }
                }
            }
            
            String my_items = "";
            for (int ele : my_products) {
                my_items += ele;
                my_items += ",";
            }
            
            if(previousList.equals("")){
                ck = new Cookie(String.valueOf(user_id), my_items);
                ck.setMaxAge(300);
            }
            else{
               ck = new Cookie(String.valueOf(user_id), my_items + previousList); 
               ck.setMaxAge(300);
            }
            
            response.addCookie(ck);
            
            System.out.println("COOKIE OLD = " + ck.getName() + " = " + ck.getValue() );

            ProductsListServlet.items.clear();
            response.sendRedirect("/HouseOfGadgets");  
        } 
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    public String getServletInfo() {
        return "Purchase Servlet";
    }
}
