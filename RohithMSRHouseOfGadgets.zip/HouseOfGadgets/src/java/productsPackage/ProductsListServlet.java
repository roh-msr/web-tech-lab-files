package productsPackage;

import java.io.IOException;
import java.util.HashMap;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "my-products", urlPatterns = {"/my-products"})
public class ProductsListServlet extends HttpServlet {
    public static HashMap<Integer, Integer> items = new HashMap();
    
    public static void addItem(int id, int q){
        items.put(id, q);
        System.out.println(items.toString());
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    }

    @Override
    public String getServletInfo() {
        return "List of products servlet!";
    }
}
