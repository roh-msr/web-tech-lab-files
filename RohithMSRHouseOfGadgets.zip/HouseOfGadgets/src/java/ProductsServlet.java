import java.io.IOException;
import java.util.HashMap;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet(name = "products", urlPatterns = {"/products"})
public class ProductsServlet extends HttpServlet {
    static HashMap<Integer, Integer> items = new HashMap();
    
    public static void addItem(int item_id, int quantity){
        items.put(item_id, quantity);
        
        System.out.println(items.toString());
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        HttpSession session = request.getSession();  
        if(session.getAttribute("email") == null){
            response.sendRedirect("/HouseOfGadgets/login");
        }
        else{
            RequestDispatcher view = request.getRequestDispatcher("/products.jsp");
            view.forward(request, response);  
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        RequestDispatcher view = request.getRequestDispatcher("/products.jsp");
        view.forward(request, response); 
    }

    @Override
    public String getServletInfo() {
        return "List of products servlet!";
    }
}
