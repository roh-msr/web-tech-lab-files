import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "login", urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {
    public static boolean validateUser(String mail, String password){
        boolean result = false;
        
        if(mail.isEmpty() || password.isEmpty()){
            return result;
        }
        
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb?autoReconnect=true&useSSL=false","jdbcuser","");
            
            PreparedStatement ps = conn.prepareStatement("SELECT email FROM gadget_user WHERE email=? AND password=?");  
            ps.setString(1, mail);  
            ps.setString(2, password);  

            ResultSet rs = ps.executeQuery();
            
            result = rs.next();
        }
        catch (SQLException | ClassNotFoundException ex) {
            System.out.println("ERROR = " + ex.getMessage());
        }
        
        return result;
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        RequestDispatcher view = request.getRequestDispatcher("/login.jsp");
        view.forward(request, response);         
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String emailId = request.getParameter("email");
        String userPassword = request.getParameter("password");
        
        if(validateUser(emailId, userPassword)){
            HttpSession session = request.getSession();  
            session.setAttribute("email", emailId);
            session.setAttribute("type", "login");
            
            response.sendRedirect("/HouseOfGadgets");
        }
        else{
            response.sendRedirect("/HouseOfGadgets/signup");
        }
    }

    @Override
    public String getServletInfo() {
        return "User login servlet!";
    }

}